## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(nowcast)
library(magrittr)

## -----------------------------------------------------------------------------
# specify time period
start_date <- '2018-01-01'
end_date <- '2019-12-31'

# use poisson model with 25 daily expected events
death_events_poi <- simulate_daily_death_event(
  start_date = start_date, 
  end_date = end_date, 
  model = 'poisson', 
  param_list = list(lambda = 25)
)

death_events_poi

## -----------------------------------------------------------------------------
death_events_norm <- simulate_daily_death_event(
  start_date = start_date, 
  end_date = end_date, 
  model = 'norm_approx', 
  param_list = list(mu = 25, sigma = 2)
)

death_events_norm

## -----------------------------------------------------------------------------
death_count_poi <- death_events_poi[, list(n_event = .N), by = date]
death_count_poi
# death_count_norm <- death_events_norm[, list(n_event = .N), by = date]

## -----------------------------------------------------------------------------
# use the simulated death event data from the poisson model
death_register <- simulate_registration(death_data = death_events_poi)

print(death_register)

hist(death_register$delay_days)

## -----------------------------------------------------------------------------
# different parameters 
death_register2 <- simulate_registration(death_data = death_events_poi, r = 10, p = 0.9)

hist(death_register2$delay_days)

