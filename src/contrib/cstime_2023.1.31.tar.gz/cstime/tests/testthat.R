library(testthat)
library(cstime)

test_check("cstime")
