knitr::knit("vignettes/csdb.Rmd.orig", "vignettes/csdb.Rmd")
