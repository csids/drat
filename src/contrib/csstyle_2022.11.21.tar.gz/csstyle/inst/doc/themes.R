## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(ggplot2)
library(csstyle)

## -----------------------------------------------------------------------------
q <- ggplot(diamonds[1:200,], aes(carat, depth, color = cut))
q <- q + geom_point(size = 4)
q <- q + csstyle::scale_color_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_basic'")
q <- q + csstyle::theme_fhi_basic()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds[1:200,], aes(carat, depth, color = cut))
q <- q + geom_point(size = 4)
q <- q + csstyle::scale_color_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines'")
q <- q + csstyle::theme_fhi_lines()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds[1:200,], aes(carat, depth, color = cut))
q <- q + geom_point(size = 4)
q <- q + csstyle::scale_color_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines_horizontal'")
q <- q + csstyle::theme_fhi_lines_horizontal()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds, aes(x=color, fill = cut))
q <- q + geom_bar()
q <- q + csstyle::scale_fill_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_basic'")
q <- q + csstyle::theme_fhi_basic()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds, aes(x=color, fill = cut))
q <- q + geom_bar()
q <- q + csstyle::scale_fill_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines'")
q <- q + csstyle::theme_fhi_lines()
q

## -----------------------------------------------------------------------------
q <- ggplot(diamonds, aes(x=color, fill = cut))
q <- q + geom_bar()
q <- q + csstyle::scale_fill_fhi(palette = "primary")
q <- q + labs(title="Theme: 'theme_fhi_lines_horizontal'")
q <- q + csstyle::theme_fhi_lines_horizontal()
q

