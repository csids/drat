library(testthat)
library(sc8)

test_check("sc8")
