Surveillance Core 8 ("sc8") is a free and open-source framework for real-time analysis and disease surveillance.

sc8 is deprecated as of 2023-03-07.

Please use [Surveillance Core 9](https://github.com/csids/sc9) instead.
