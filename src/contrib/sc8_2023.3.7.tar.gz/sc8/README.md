# sc8 <a href="https://www.csids.no/sc8/"><img src="man/figures/logo.png" align="right" width="120" /></a>

Surveillance Core 8 ("sc8") is a free and open-source framework for real-time analysis and disease surveillance.

sc8 is deprecated as of 2023-03-07.

Please use [Surveillance Core 9](https://www.csids.no/sc9/) instead.
