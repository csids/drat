# Evaluates all arguments (see #81)
#' @noRd
force_all <- function(...) list(...)
