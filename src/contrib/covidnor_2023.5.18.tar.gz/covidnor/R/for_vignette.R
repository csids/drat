# this script is to store some development code for vignette


# total


# originally the data had


# try to get weekly, nation, cases

# case_test <- total[granularity_time == 'isoyearweek' &
#                      granularity_geo == 'nation',
#                    .(cases_by_testdate_n)]
#
#
# plot(case_test$cases_by_testdate_n)



