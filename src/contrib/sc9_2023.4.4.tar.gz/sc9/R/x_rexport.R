#' @import data.table
#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`
