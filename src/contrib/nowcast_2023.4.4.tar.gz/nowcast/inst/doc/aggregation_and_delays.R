## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(nowcast)
library(magrittr)

## -----------------------------------------------------------------------------
data_fake_nowcasting_raw

## -----------------------------------------------------------------------------
weekly_counts <- count_weekly_reporting(
  data = data_fake_nowcasting_raw, 
  aggregation_date = as.Date('2020-01-01'), 
  max_week_delay = 4)
weekly_counts

## -----------------------------------------------------------------------------
weekly_counts_p <- count_weekly_reporting(
  data = data_fake_nowcasting_raw, 
  aggregation_date = as.Date('2020-01-01'), 
  max_week_delay = 4, 
  keep_weekly_prob = T)
weekly_counts_p

## -----------------------------------------------------------------------------
data_fake_nowcasting_aggregated

## -----------------------------------------------------------------------------
data_fake_nation

