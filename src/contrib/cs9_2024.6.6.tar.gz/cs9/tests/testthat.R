library(testthat)
library(cs9)

test_check("cs9")
