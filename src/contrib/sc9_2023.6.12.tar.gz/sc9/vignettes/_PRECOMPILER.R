knitr::knit("vignettes/sc9.Rmd.orig", "vignettes/sc9.Rmd")
knitr::knit("vignettes/file-layout.Rmd.orig", "vignettes/file-layout.Rmd")
