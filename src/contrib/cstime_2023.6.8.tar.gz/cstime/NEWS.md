# Version 2023.5.3

- Inclusion of `now_c` that gives the current time in character format.

# Version 2023.4.26

- Uses binary searches to improve speed on date conversions.

# Version 2023.4.25

- Implements `csutils::apply_fn_via_hash_table` to speed up the conversion functions.