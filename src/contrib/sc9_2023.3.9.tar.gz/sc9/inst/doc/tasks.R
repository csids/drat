## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
options(knitr.kable.NA = '')

## ---- include=FALSE-----------------------------------------------------------
library(data.table)
library(magrittr)

## ----definitions, echo=FALSE--------------------------------------------------
d <- rbindlist(list(
  data.table(
    Object = glue::glue("argset"),
    Description = glue::glue(
      "A named list containing arguments."
    )
  ),
  data.table(
    Object = glue::glue("plnr analysis"),
    Description = glue::glue(
      "These are the fundamental units that are scheduled in plnr:
<ul>
  <li>1 argset</li>
  <li>1 function that takes two (or more) arguments:
    <ul>
      <li>data (named list)</li>
      <li>argset (named list)</li>
      <li>... (optional arguments)</li>
    </ul>
  </li>
</ul>
"
    )
  ),
  data.table(
    Object = glue::glue("data_selector_fn"),
    Description = glue::glue(
      "A function that takes two arguments:
<ul>
  <li>argset (named list)</li>
  <li>schema (named list)</li>
</ul>
This function provides a named list to be used as the `data` argument to `action_fn`
"
    )
  ),
  data.table(
    Object = glue::glue("action_fn"),
    Description = glue::glue(
      "A function that takes three arguments:
<ul>
  <li>data (named list, returned from data_selector_fn)</li>
  <li>argset (named list)</li>
  <li>schema (named list)</li>
</ul>
This is the thing that **'does stuff'** in Sykdomspulsen Core.
"
    )
  ),
  data.table(
    Object = glue::glue("sc analysis"),
    Description = glue::glue(
      "A `sc analysis` is essentially a `plnr analysis` with database schemas:
<ul>
  <li>1 argset</li>
  <li>1 action_fn</li>
</ul>
"
    )
  ),
  data.table(
    Object = glue::glue("plan"),
    Description = glue::glue(
      "
<ul>
  <li>1 data-pull (using data_selector_fn)</li>
  <li>1 list of sc analyses</li>
</ul>
"
    )
  ),
  data.table(
    Object = glue::glue("task"),
    Description = glue::glue(
      "
This is is the unit that Airflow schedules.
<ul>
  <li>1 list of plans</li>
</ul>
We sometimes run the list of plans in parallel.
"
    )
  )
))
tab <- fhiplot::htmltable_quick_style(d, widths = c(20, 80)) %>%
  htmlTable::htmlTable(
    rnames = FALSE,
    align = "|l|l|",
    align.header = "|l|l|",
    align.cgroup = "|l|l|",
    spacer.celltype = "skip",
    caption = NULL
  )
tab

## ----general-tasks, fig.cap="A general task showing the many options of a task.", out.width = "100%", echo = FALSE----
knitr::include_graphics(system.file("vignette_resources/tasks/task_general.png",package="sc9"))

## ----file-locations, fig.cap="A typical file setup for an implementation of Sykdomspulsen Core. $plan_argset_fn$ is rarely used, and is therefore shown as blacked out in the most of the tasks.", out.width = "100%", echo = FALSE----
knitr::include_graphics(system.file("vignette_resources/tasks/file_locations.png",package="sc9"))

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/addins_1.png",package="sc9"))

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/addins_2.png",package="sc9"))

## ---- echo=T, eval=F----------------------------------------------------------
#  for_each_plan <- list()
#  for_each_plan[[1]] <- list(
#    var_1 = 1,
#    var_2 = "a"
#  )
#  for_each_plan[[2]] <- list(
#    var_1 = 2,
#    var_2 = "b"
#  )
#  for_each_plan[[3]] <- list(
#    var_1 = 1,
#    var_2 = "a"
#  )
#  for_each_plan[[4]] <- list(
#    var_1 = 2,
#    var_2 = "b"
#  )

## ---- echo=T------------------------------------------------------------------
plnr::expand_list(
  x = 1
)

## ---- echo=T------------------------------------------------------------------
for_each_plan <- plnr::expand_list(
  var_1 = c(1,2),
  var_2 = c("a", "b")
)
for_each_plan

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/addins_3.png",package="sc9"))

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/task_import_data.png",package="sc9"))

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/task_analysis.png",package="sc9"))

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/task_export_multiple.png",package="sc9"))

## ---- echo=T, eval=F----------------------------------------------------------
#  sc::add_task_from_config_v8(
#    name_grouping = "example",
#    name_action = "export_results",
#    name_variant = NULL,
#    cores = 1,
#    plan_analysis_fn_name = NULL,
#    for_each_plan = plnr::expand_list(
#      location_code = fhidata::norway_locations_names()[granularity_geo %in% c("county")]$location_code
#    ),
#    for_each_analysis = NULL,
#    universal_argset = list(
#      folder = sc::path("output", "example")
#    ),
#    upsert_at_end_of_each_plan = FALSE,
#    insert_at_end_of_each_plan = FALSE,
#    action_fn_name = "example_export_results_action",
#    data_selector_fn_name = "example_export_results_data_selector",
#    schema = list(
#      # input
#      "input" = sc::config$schemas$input
#  
#      # output
#    ),
#    info = "This task does..."
#  )

## ---- out.width = "100%", echo = FALSE----------------------------------------
knitr::include_graphics(system.file("vignette_resources/tasks/task_export_combined.png",package="sc9"))

## ---- echo=T, eval=F----------------------------------------------------------
#  sc::add_task_from_config_v8(
#    name_grouping = "example",
#    name_action = "export_results",
#    name_variant = NULL,
#    cores = 1,
#    plan_analysis_fn_name = NULL,
#    for_each_plan = plnr::expand_list(
#      x = 1
#    ),
#    for_each_analysis = NULL,
#    universal_argset = list(
#      folder = sc::path("output", "example"),
#      granularity_geos = c("nation", "county")
#    ),
#    upsert_at_end_of_each_plan = FALSE,
#    insert_at_end_of_each_plan = FALSE,
#    action_fn_name = "example_export_results_action",
#    data_selector_fn_name = "example_export_results_data_selector",
#    schema = list(
#      # input
#      "input" = sc::config$schemas$input
#  
#      # output
#    ),
#    info = "This task does..."
#  )

