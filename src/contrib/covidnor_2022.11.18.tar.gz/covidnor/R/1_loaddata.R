#' Dummy function placeholder
#'
#'
#' @param x a number
#' @param y another number
#' @examples
#' x <- 3
#' y <- 4
#'
#' z <- dummy_fn(x, y)
#' @return the sum
#'
#' @export

dummy_fn <- function(x, y){
  x+y
}
