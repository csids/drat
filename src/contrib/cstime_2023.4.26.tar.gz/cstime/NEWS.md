# Version 2023.4.26

- Uses binary searches to improve speed on date conversions.

# Version 2023.4.25

- Implements `csutils::apply_fn_via_hash_table` to speed up the conversion functions.