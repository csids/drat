# Version 2023.4.21

- Reintroduction of `plot_epicurve`
- Vignette for epicurves
- Vignette for cstyle

# Version 2023.4.18

- Consistent renaming of formatting functions. 
