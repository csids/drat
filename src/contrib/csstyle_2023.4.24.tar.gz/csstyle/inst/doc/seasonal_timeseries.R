## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(magrittr)

## -----------------------------------------------------------------------------
d_day <- covidnor::total[
  granularity_geo=="county" & 
  granularity_time=="day",
  .(
    isoyear,
    date,
    location_code,
    location_name,
    cases_by_testdate_n,
    cases_by_testdate_vs_pop_pr100000
  )
] %>% 
  print()
d_isoweek <- covidnor::total[
  granularity_geo=="county" & 
  granularity_time=="isoweek",
  .(
    isoyear,
    isoyearweek,
    season,
    seasonweek,
    location_code,
    location_name,
    cases_by_testdate_n,
    cases_by_testdate_vs_pop_pr100000
  )
] %>% 
  print()

## -----------------------------------------------------------------------------
csstyle::plot_seasonal_timeseries(
  d_isoweek[location_code %in% c("county_nor03")],
  var_x = "isoyearweek",
  var_y = "cases_by_testdate_vs_pop_pr100000",
  breaks_x = seq(1,52, 4),
  # breaks_x = csstyle::every_nth(8),
  #breaks_x = c(3, 6),
  wide_table = FALSE,
  var_group = "season"
)

