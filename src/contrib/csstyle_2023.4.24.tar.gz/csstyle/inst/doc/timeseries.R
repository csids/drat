## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## -----------------------------------------------------------------------------
library(magrittr)

## -----------------------------------------------------------------------------
d_day <- covidnor::total[
  granularity_geo=="county" & 
  granularity_time=="day",
  .(
    isoyear,
    date,
    location_code,
    location_name,
    cases_by_testdate_n,
    cases_by_testdate_vs_pop_pr100000
  )
] %>% 
  print()
d_isoweek <- covidnor::total[
  granularity_geo=="county" & 
  granularity_time=="isoweek",
  .(
    isoyear,
    isoyearweek,
    season,
    seasonweek,
    location_code,
    location_name,
    cases_by_testdate_n,
    cases_by_testdate_vs_pop_pr100000
  )
] %>% 
  print()

## -----------------------------------------------------------------------------
csstyle::plot_timeseries(
  d_day[location_code=="county_nor03"],
  var_x = "date",
  var_y = c("Cases" = "cases_by_testdate_n"),
  breaks_x = "2 months"
)

## -----------------------------------------------------------------------------
csstyle::plot_timeseries(
  d_isoweek[location_code %in% c("county_nor03", "county_nor50")],
  var_x = "isoyearweek",
  var_y = "cases_by_testdate_vs_pop_pr100000",
  breaks_x = csstyle::every_nth(8),
  wide_table = FALSE,
  var_group = "location_name"
)

