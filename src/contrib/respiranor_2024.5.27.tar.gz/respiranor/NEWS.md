# respiranor 2023.5.18

Added documentation:

* [Data details](https://www.csids.no/respiranor/articles/data_details.html): more detailed information on data included in the package


# respiranor 2023.4.20

- `total` dataset is released for total age/sex in Norway.
