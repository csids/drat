library(testthat)
library(csmaps)

test_check("csmaps")
