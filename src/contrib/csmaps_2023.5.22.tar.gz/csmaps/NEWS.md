# Version 2023.5.22

- Included county maps for 2024 borders.

# Version 2022.6.8

- Refactored the .rd files.

# Version 2022.6.6

- Migrated content from fhimaps to csmaps

- Updated documentation

# Version 2020.2.17

- Package is created (previously as fhimaps)
