# Version 2023.5.22

- Included maps for [2024](https://www.regjeringen.no/no/tema/kommuner-og-regioner/kommunestruktur/nye-kommune-og-fylkesnummer-fra-1.-januar-2024/id2924701/?expand=factbox2924711) borders.

# Version 2022.6.8

- Refactored the .rd files.
