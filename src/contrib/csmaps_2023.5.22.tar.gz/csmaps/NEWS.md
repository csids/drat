# Version 2023.5.22

- Included maps for 2024 borders.

# Version 2022.6.8

- Refactored the .rd files.
