# Version 2024.4.21

- Include population data for 2023.
- [CRAN submission](https://github.com/csids/csdata/releases/tag/2023.4.21)
