# Surveillance Core 9 (sc9) <a href="https://docs.sykdomspulsen.no/sc"><img src="man/figures/logo.png" align="right" width="120" /></a>

## Overview 

[Surveillance Core 9](https://docs.sykdomspulsen.no/sc) ("sc9") is a free and open-source framework for real-time analysis and disease surveillance.
