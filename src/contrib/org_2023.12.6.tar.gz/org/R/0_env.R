#' Folders to be used/referenced (environment)
#' @export project
project <- new.env()
