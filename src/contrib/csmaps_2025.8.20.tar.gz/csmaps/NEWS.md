# Version 2025.8.21

CRAN submission.

## Documentation
* Improved pkgdown reference organization by grouping datasets by geographic level

## Bug Fixes
* Fixing Akershus in the 2024 maps

# Version 2023.5.25

- Inclusion of annotate_oslo_nor_map_bxxxx_split_dt, nor_county_position_geolabels_b2024_split_dt, nor_county_position_geolabels_b2020_split_dt.

# Version 2023.5.22

- Included maps for [2024](https://www.regjeringen.no/no/tema/kommuner-og-regioner/kommunestruktur/nye-kommune-og-fylkesnummer-fra-1.-januar-2024/id2924701/?expand=factbox2924711) borders.
- CRAN submission.

# Version 2022.6.8

- Refactored the .rd files.
