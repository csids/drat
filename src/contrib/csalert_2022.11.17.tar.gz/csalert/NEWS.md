# csalert 2022.5.6

- short_term_trend now allows for vectorized prX and statistics_naming_prefix.

# csalert 2022.4.22

- short_term_trend now allows for granularity_time=='isoweek' and denominators.

# csalert 2022.4.21

- short_term_trend created to allow for easy estimation of short-term trends (increasing/decreasing/null), doubling time in days, and short-term forecasting with prediction intervals.
- prediction_interval created to allow for easy estimation of prediction intervals after fitting glms (family = poisson and quasipoisson) based on Farrington 1996.

# csalert 2022.4.10

- Package is created
