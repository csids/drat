## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----echo=FALSE, include=FALSE------------------------------------------------
library(data.table)
library(magrittr)

## -----------------------------------------------------------------------------
d <- spltidy::generate_test_data()
spltidy::set_splfmt_rts_data_v1(d)

# Looking at the dataset
d[]

## -----------------------------------------------------------------------------
d <- spltidy::generate_test_data()[1:5]
spltidy::set_splfmt_rts_data_v1(d)

# Looking at the dataset
d[]

# Smart assignment of time columns (note how granularity_time, isoyear, isoyearweek, date all change)
d[1,isoyearweek := "2021-01"]
d

# Smart assignment of time columns (note how granularity_time, isoyear, isoyearweek, date all change)
d[2,isoyear := 2019]
d

# Smart assignment of time columns (note how granularity_time, isoyear, isoyearweek, date all change)
d[4:5,date := as.Date("2020-01-01")]
d

# Smart assignment fails when multiple time columns are set
d[1,c("isoyear","isoyearweek") := .(2021,"2021-01")]
d

# Smart assignment of geo columns
d[1,c("location_code") := .("norge")]
d

# Collapsing down to different levels, and healing the dataset 
# (so that it can be worked on further with regards to real time surveillance)
d[, .(deaths_n = sum(deaths_n), location_code = "norge"), keyby=.(granularity_time)] %>%
  spltidy::create_unified_columns() %>%
  print()

# Collapsing down to different levels, without healing the dataset and without
# removing the class splfmt_rts_data_v1 (this is uncommon)
d[, .(deaths_n = sum(deaths_n), location_code = "norge"), keyby=.(granularity_time)] %>%
  print()

# Collapsing to different levels, and removing the class splfmt_rts_data_v1 because
# it is going to be used in new output/analyses
d[, .(deaths_n = sum(deaths_n), location_code = "norge"), keyby=.(granularity_time)] %>%
  spltidy::remove_class_splfmt_rts_data() %>%
  print()

## -----------------------------------------------------------------------------
spltidy::generate_test_data() %>%
  spltidy::set_splfmt_rts_data_v1() %>%
  summary()

## -----------------------------------------------------------------------------
spltidy::generate_test_data() %>%
  spltidy::set_splfmt_rts_data_v1() %>%
  spltidy::identify_data_structure("deaths_n") %>%
  plot()

