# csmaps 2022.6.8

- Refactored the .rd files.

# csmaps 2022.6.6

- Migrated content from fhimaps to csmaps

- Updated documentation

# csmaps 2020.2.17

- Package is created (previously as fhimaps)
