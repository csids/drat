library(testthat)
library(sc9)

test_check("sc9")
