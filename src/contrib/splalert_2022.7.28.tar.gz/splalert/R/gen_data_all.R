gen_data_all <- function(base_loc) {
  # gen_data_all(file.path(getwd(),"data"))
  # base_loc = file.path(getwd(),"data")

  # ____ norway locations ____ ----

  # 1. redistricting ----
  # norway_locations_redistricting_b2020 <- nor_loc_redistricting_all(2020)
  # save(norway_locations_redistricting_b2020, file = file.path(base_loc, paste0("norway_locations_redistricting_b2020",".rda")), compress = "xz")
}
