# covidnor 2023.4.20

- `total` dataset is released for total age/sex in Norway.
