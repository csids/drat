knitr::knit("vignettes/csreport.Rmd.orig", "vignettes/csreport.Rmd")
