library(testthat)
library(csstyle)

test_check("csstyle")
