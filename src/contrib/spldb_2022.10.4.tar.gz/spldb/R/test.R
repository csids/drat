#' blah
#' @examples
#' x()
#' @export
x <- function(){
  print(2)
}
