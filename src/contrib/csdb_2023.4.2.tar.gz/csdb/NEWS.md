# Version 2023.4.2

- `create_table` now automatically adds the indexes

# Version 2023.3.31

- Removing info messages from `drop_rows_where`

# Version 2023.3.8

- connect() in DBConnection_v9 is smarter, more robust with error checking and making fewer useless calls to the db. Tries to connect twice now before throwing an error.
- autoconnection is now more robust in DBConnection_v9

# Version 2020.2.17

- Package is created
